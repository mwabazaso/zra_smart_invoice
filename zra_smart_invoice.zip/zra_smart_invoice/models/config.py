from symtable import Class

from odoo import models, fields, api

import logging

_logger = logging.getLogger(__name__)

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    fetch_data_button = fields.Boolean(string="Fetch Data")

    def fetch_data(self):
        try:
            # Fetch and store classification data
            result = self.env['zra.item.data'].fetch_and_store_classification_data()
            if result is False:
                _logger.warning("Classification data fetch did not return success.")

            # Fetch common code data
            common_data = self.env['code.data'].fetch_common_code_data()
            if not common_data:
                _logger.warning("Common code data fetch returned empty data.")

            # Store quantity unit data
            if not self.env['quantity.unit.data'].store_quantity_data(common_data):
                _logger.warning("Failed to store quantity unit data.")

            # Store packaging unit data
            if not self.env['packaging.unit.data'].store_packaging_data(common_data):
                _logger.warning("Failed to store packaging unit data.")

            # Store country data
            if not self.env['country.data'].store_country_data(common_data):
                _logger.warning("Failed to store country data.")

            _logger.info("Data fetched and stored successfully.")

            # Return success notification
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Success',
                    'message': 'Data fetched and stored successfully.',
                    'type': 'success',
                    'sticky': False,
                }
            }

        except Exception as e:
            # Log the error with traceback
            _logger.error(f"Error fetching and storing data: {e}", exc_info=True)

            # Return failure notification
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Error',
                    'message': f"Failed to fetch and store data: {str(e)}",
                    'type': 'danger',
                    'sticky': True,
                }
            }